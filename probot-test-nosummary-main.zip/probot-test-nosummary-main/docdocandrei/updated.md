2022-12-06 09:48:53
## Google sheets
::embed{url="https://docs.google.com/spreadsheets/d/1R_xTndeC-jzOxHJWd5P4fuKWQ2U2q9PSpp5luHRRfNY/edit#gid=0"}

## Google docs
::embed{url="https://docs.google.com/document/d/1jTM4gUFIjvxpC88HNsAI-hWDkf7EscDzQh1r_QFlvV8/edit#heading=h.f1pso1jruysd"}

## Google slides
::embed{url="https://docs.google.com/presentation/d/1vmmwSOws35J2iGgy5XEzUYFvIzQHr0XnPBdbwFQtklQ/edit#slide=id.g101d6defc9_20_0"}

## Miro
::embed{url="https://miro.com/app/board/o9J_lU-qYRw=/"}

## Figma
::embed{url="https://www.figma.com/file/cw2RcZoZeRW200Jq4fb5cc/Untitled?node-id=0%3A1"}
