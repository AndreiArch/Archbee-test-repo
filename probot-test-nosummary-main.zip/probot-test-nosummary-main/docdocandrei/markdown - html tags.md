# Markdown htmltag -> Accepted tags

## html images :rocket:


{% file src="assets/AEP Foundations Bootcamp (Labs).postman_collection.jpg" %}
Bootcamp API Collection File
{% endfile %}

{% hint style="success" %}
Congratulations!  You are ready to start using the Experience Platform APIs
{% endhint %}

### image

<img src="https://placehold.co/600x400/EEE/31343C" alt="Crypto exchange" />

### single line image

Before you continue we want to double check that your access is legit. Perform the following steps:

1. Open the folder titled `Check Sandbox Access` and click on the call titled `Retrieve Your Sandbox`
2. Next in the upper right corner of Postman you'll see an Environment drop-down box.  Be sure to select the `AEP Bootcamp` environment
3. Execute the call by clicking the `Send` button

<figure><img src="https://placehold.co/600x400/EEE/31343C" alt=""><figcaption><p>Retrieve your sandbox API call</p></figcaption></figure>

A successful response will look like so:

<figure><img src="https://placehold.co/600x400/EEE/31343C" alt=""><figcaption><p>200 OK Successful sandbox request</p></figcaption></figure>

### Multi line image

<figure>
    <img src="https://picsum.photos/id/1/200/300"
         alt="Albuquerque, New Mexico">
    <figcaption>A single track trail outside of Albuquerque, New Mexico.</figcaption>
</figure>

## HTML Links

### links in lists

- <a href="asadasd" title="Chuck Norris " target="_blank" >wowoww</a>
- A JCV <a href="asadasd" title="JCV" target="_blank" >profil</a>

## link in paragraph

<a href="asadasd" title="Alup Igus " target="_blank" >wowoww</a>

<a href="https://flaviocopes.com/mysql-how-to-install"> starts with link </a> :

link in the middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> end text

link in the middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> asdas middle <a href="https://flaviocopes.com/mysql-how-to-install"> middle klink</a> end text

## table

### short table

| First Header | Second Header |
| ------------ | ------------- |
| Content Cell | Content Cell  |
| Content Cell | Content Cell  |

## Emoji in paragraph

:memo: **Note:** Sunrises are beautiful.

### emoji in blockquote and text color

- ~~The world is flat.~~ We now know that the world is round. <font color="red">This text is red!</font>

> :warning: **Warning:** Do not push the big red button.

> :memo: **Note:** Sunrises are beautiful.

> :bulb: **Tip:** Remember to appreciate the little things in life.

## special text

- Copyright (©) — &copy;
- Registered trademark (®) — &reg;
- Trademark (™) — &trade;
- Euro (€) — &euro;
- Left arrow (←) — &larr;
- Up arrow (↑) — &uarr;
- Right arrow (→) — &rarr;
- Down arrow (↓) — &darr;
- Degree (°) — &#176;
- Pi (π) — &#960;
