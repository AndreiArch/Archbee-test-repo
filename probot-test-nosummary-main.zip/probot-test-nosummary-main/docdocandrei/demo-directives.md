---
title: Demo directives 2221----111
createdAt: 2022-11-29T12:12:19.000Z
updatedAt: 2022-12-05T11:47:57.000Z
---

::partial{file="header.md"}

Sometimes this ↓ text isn't redered properly because of directives

something\:something
something: something

## Get Cakes--23-w-sdd-sa-d-aqs-d-asd-asdas

Get a cake by its ID

### Code examples

```javascript
var myHeaders = new Headers();
myHeaders.append("Accept", "application/json");

var raw = "{\"id\":\"string\"}";

var requestOptions = {
   method: 'GET',
   headers: myHeaders,
   body: raw,
   redirect: 'follow'
};

fetch("https://api.cakes.com", requestOptions)
   .then(response => response.text())
   .then(result => console.log(result))
   .catch(error => console.log('error', error));
```

### Responses

:::codeblocktabs
```200
{
    "name": "Cake's name",
  }
```

```404
{
    "message": "Ain't no cake like that."
  }
```
:::

\-unhandled content type-

This is a bold **text**

<http://www.archbee.io>

## Tabs

:::::tabs
::::tab{title="Tab 1"}
Some content for Tab 1

:::hint{style="info"}
Pull requests are very welcome! Please see CONTRIBUTING.md for more information.
Tthis is really nice
:::

*   [x] This is a checkbox list
*   [x] This is a checkbox list
*   [ ] This is done
*   [ ] This is a checkbox list
    \::::

:::tab{title="Tab Photos"}
![](https://placehold.co/600x400)

We would love you to contributeaaa
:::
::::
:::::

***

## Hints

:::hint
We would love you to contribute to `@octokit/rest`, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint
We would love you to contribute to `@octokit/rest`, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint{style="warning"}
We would love you to contribute to @octokit/rest, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

:::hint{style="success"}
We would love you to contribute to @octokit/rest, pull requests are very welcome! Please see CONTRIBUTING.md for more information.
:::

***

## Link Array

:::::link-array
:::link-array-item{attributes="[object Object]" headerType="IMAGE" headerImage="https://placehold.co/600x400"}
*   list item 1

*   list item 2

*   asedfadsf

*   asdf

*   asdf

*   sad

*   fasdf

*   asda

*   safsdfasdfasd

*   asasdfasdfsd

*
:::

::::link-array-item{attributes="[object Object]" headerType="COLOR" headerColor="#ff00FF"}
*   [ ] unchecked list box
*   [x] checked list box
    \:::
    \::::

## Code block

```nodejs
dadada
```

## Code blocks

:::codeblocktabs
    // code block not specified

<!---->

    // code block not specified

<!---->

    // code block not specified
:::
::::
:::::

## Demo Code Blocks

:::codeblocktabs
```php
// PHP is the best.
```

```java
// and JAVA too
```

```go
// demo go
```

```javascript
// demo js
- asdfasd
asdfasdasdfasd
```
:::

***

:::hint
some hint
:::

***

::::tabs
:::tab{title="tab 2"}
some tab fasdfasdfasdfasdfads
:::

:::tab{title="tab 2"}
some tab fasdfasdfasdfasdfads
:::

:::tab{title="tab 2"}
some tab fasdfasdfasdfasdfads
:::

:::tab{title="tab 2"}
some tab fasdfasdfasdfasdfads
:::
::::
## Google sheets
::embed{url="https://docs.google.com/spreadsheets/d/1R_xTndeC-jzOxHJWd5P4fuKWQ2U2q9PSpp5luHRRfNY/edit#gid=0"}

## Google docs
::embed{url="https://docs.google.com/document/d/1jTM4gUFIjvxpC88HNsAI-hWDkf7EscDzQh1r_QFlvV8/edit#heading=h.f1pso1jruysd"}

## Google slides
::embed{url="https://docs.google.com/presentation/d/1vmmwSOws35J2iGgy5XEzUYFvIzQHr0XnPBdbwFQtklQ/edit#slide=id.g101d6defc9_20_0"}

## Miro
::embed{url="https://miro.com/app/board/o9J_lU-qYRw=/"}

## Figma
::embed{url="https://www.figma.com/file/cw2RcZoZeRW200Jq4fb5cc/Untitled?node-id=0%3A1"}
