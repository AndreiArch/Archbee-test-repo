### Test Changelog

:::changelog{title="v1.2 Release"}
::changelog-item{type="added" description="Editor V2"}
::changelog-item{type="improved" description="Lists"}
::changelog-item{type="fixed" description="Github Sync"}
::changelog-item{type="fixe123123123d" description="Tables"}
::changelog-item{description="Changelog Markdown"}
:::


### Test Changelog empty items

:::changelog{title="v1.2 Release"}
:::

### Test changelog invalid typs

:::changelog{title="v1.2 Release"}
::changelog-item{type="added" }
::changelog-item{type="undefined64"}
::changelog-item{description="no type"}
:::