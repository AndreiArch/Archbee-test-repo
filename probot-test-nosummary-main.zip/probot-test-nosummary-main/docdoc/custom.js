window._archbee = window._archbee || {
    queue: [],
    push: function (x) {window._archbee.queue.push(x)}
  };

  window._archbee.push({
    eventType: "init",
    spaceId: "PUBLISHED-0AUu0NJ_zFLC52lH2Yy5U",
  });