
# asdas dasdsa

:::codeblocktabs
```php
PHP is the best.
```

```java
and JAVA too
```

```go
dadada
```

```text_1
dadada sss
```
:::

