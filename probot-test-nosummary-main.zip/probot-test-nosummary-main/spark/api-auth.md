
# API Authentication

Authentication with SparkLayer works by creating a OAuth client credential for the environment within our dashboard and authenticating with an OAuth2 flow so that every user that uses the application gets assigned an individualised token.

### Environment Domain

Depending on the environment you access, the domain denotes the environment you are using:
Live - `https://app.sparklayer.io`
Test - `https://test.app.sparklayer.io`

### Retrieving an access token

Create a `POST` request to the `/api/auth/token` using the domain above. The Client ID and secret must be taken from the dashboard. It must have a header of `Content-type=application/json` and the `Site-Id` provided from the dashboard when creating an API key. It's recommended to set the `User-Agent` to help us debug any issues you may encounter.
```
{
  "grant_type": "client_credentials",
  "client_id": "c466d1fb-1af1-4437-a25c-03e8f94814bf",
  "client_secret": "7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV"
}
```
If the details are correct you will recieve the below:
```
{
  "token_type": "Bearer",
  "expires_in": 3600,
  "access_token": "7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV"
}
```

Once the above is complete, using the `access_token` retrieved, it is then sent as a header with all requests like so `Authorization: Bearer 7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV`.

Once the token expiries it is no longer valid.

### Example Auth Request:
```
POST /api/auth/token HTTP/1.1
Site-Id: exampleclient
Content-Type: application/json
Host: app.sparklayer.io
User-Agent: exampleclient

{
  "grant_type": "client_credentials",
  "client_id": "c466d1fb-1af1-4437-a25c-03e8f94814bf",
  "client_secret": "7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV"
}
```
### Example Auth Response:
```
HTTP/1.1 200 OK
Content-Type: application/json
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: authorization, content-type, site-id
Access-Control-Max-Age: 7200
Access-Control-Allow-Methods: GET, POST, PUT, DELETE

{"token_type":"Bearer","expires_in":3600,"access_token":"7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV"}
```
### Example API Request:
```
GET /api/v1/price-lists HTTP/1.1
Site-Id: exampleclient
Content-Type: application/json
Host: app.sparklayer.io
User-Agent: exampleclient
Authorization: Bearer 7zA5ltJNkiI2WzhU90fTmYJANRcXYJPXsB8SnIEM3x37B2genuwqyv5tVdfLkUWV
```
### Example API Response:
```
HTTP/1.1 200 OK
Content-Type: application/json
Access-Control-Allow-Origin: *
Access-Control-Allow-Headers: authorization, content-type, site-id
Access-Control-Max-Age: 7200
Access-Control-Allow-Methods: GET, POST, PUT, DELETE

[]
```