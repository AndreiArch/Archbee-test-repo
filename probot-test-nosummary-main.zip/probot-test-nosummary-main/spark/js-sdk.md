## Modules

<dl>
<dt><a href="#module_spark">spark</a></dt>
<dd><p>Attached to window (used as window.spark), when SparkLayer has completed loading and a user is logged in.</p>
</dd>
<dt><a href="#module_options">options</a></dt>
<dd><p>The options available when using SparkLayer JS, these are set through window.sparkOptions</p>
</dd>
</dl>

<a name="module_spark"></a>

## spark
Attached to window (used as window.spark), when SparkLayer has completed loading and a user is logged in.


* [spark](#module_spark)
    * _static_
        * [.isLoggedIn()](#module_spark.isLoggedIn) ⇒ <code>Promise.&lt;boolean&gt;</code>
        * [.initialiseRemoteData()](#module_spark.initialiseRemoteData) ⇒ <code>Promise.&lt;UserData&gt;</code>
        * [.switchImpersonatingCustomer(customerId)](#module_spark.switchImpersonatingCustomer) ⇒ <code>Promise.&lt;UserData&gt;</code>
        * [.fetch(query, variables)](#module_spark.fetch) ⇒ <code>Promise.&lt;Response&gt;</code>
        * [.updateCart(input, cartSuccessHandledLocally, cartErrorsHandledLocally)](#module_spark.updateCart) ⇒ <code>Promise.&lt;(null\|\*)&gt;</code>
        * [.externalClearBasket()](#module_spark.externalClearBasket) ⇒ <code>Promise.&lt;void&gt;</code>
        * [.getProduct(parentProductId)](#module_spark.getProduct) ⇒ <code>Promise.&lt;Product&gt;</code>
        * [.getVariant(parentProductId, variantSku)](#module_spark.getVariant) ⇒ <code>Promise.&lt;ProductVariant&gt;</code>
        * [.getPackSizeForVariant(parentProductId, variantSku)](#module_spark.getPackSizeForVariant) ⇒ <code>Promise.&lt;number&gt;</code>
        * [.getRrpPriceForVariant(parentProductId, variantSku)](#module_spark.getRrpPriceForVariant) ⇒ <code>Promise.&lt;{rrp: (number\|null), currencyCode: string}&gt;</code>
        * [.getPricingForVariant(parentProductId, variantSku)](#module_spark.getPricingForVariant) ⇒ <code>Promise.&lt;{price: number, rrp: number, priceBreaks: Array.&lt;PriceBreaks&gt;, currencyCode: string}&gt;</code>
        * [.getPriceForProduct(parentProductId)](#module_spark.getPriceForProduct) ⇒ <code>Promise.&lt;{numberOfPrices: number, numberOfPricesExcludingBreaks: number, fromPrice: (number\|null), fromPriceExcludingBreaks: (number\|null), rrpPrice: (number\|null), currencyCode: string, hasPriceBreaks: boolean}&gt;</code>
        * [.calculatePricingForVariant(parentProductId, variantSku, qty, qtyAcrossVariants)](#module_spark.calculatePricingForVariant) ⇒ <code>Promise.&lt;{unitPrice: number, rrp: (number\|null), totalPrice: (number\|null), priceBreakSavingsPercentage: (number\|null), hasPriceBreaks: boolean, currencyCode: (string), priceBreaks: (Array.&lt;PriceBreaks&gt;), basePrice: number}&gt;</code>
        * [.getCart()](#module_spark.getCart) ⇒ <code>Promise.&lt;object&gt;</code>
    * _inner_
        * [~UserData](#module_spark..UserData) : <code>Object</code>
        * [~CartItemInput](#module_spark..CartItemInput) : <code>Object</code>
        * [~UpdateCart](#module_spark..UpdateCart) : <code>Object</code>
        * [~Price](#module_spark..Price) : <code>Object</code>
        * [~PriceBreaks](#module_spark..PriceBreaks) : <code>Object</code>
        * [~Product](#module_spark..Product) : <code>Object</code>
        * [~ProductVariant](#module_spark..ProductVariant) : <code>Object</code>

<a name="module_spark.isLoggedIn"></a>

### spark.isLoggedIn() ⇒ <code>Promise.&lt;boolean&gt;</code>
Check if user is logged in

**Kind**: static method of [<code>spark</code>](#module_spark)  
<a name="module_spark.initialiseRemoteData"></a>

### spark.initialiseRemoteData() ⇒ <code>Promise.&lt;UserData&gt;</code>
Fetchs logged in customer data and site related data

**Kind**: static method of [<code>spark</code>](#module_spark)  
<a name="module_spark.switchImpersonatingCustomer"></a>

### spark.switchImpersonatingCustomer(customerId) ⇒ <code>Promise.&lt;UserData&gt;</code>
Switch impersonating customer or end impersonation with null

**Kind**: static method of [<code>spark</code>](#module_spark)  

| Param | Type |
| --- | --- |
| customerId | <code>string</code> \| <code>null</code> | 

<a name="module_spark.fetch"></a>

### spark.fetch(query, variables) ⇒ <code>Promise.&lt;Response&gt;</code>
Run a GraphQL query (with the user authenticated)

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;Response&gt;</code> - Returns a promise which resolves to standard JS response object (use status and data)  

| Param | Description |
| --- | --- |
| query | GraphQL query string |
| variables | GraphQL variables |

<a name="module_spark.updateCart"></a>

### spark.updateCart(input, cartSuccessHandledLocally, cartErrorsHandledLocally) ⇒ <code>Promise.&lt;(null\|\*)&gt;</code>
Run an update cart mutation, shows appropriate toasts and returns result

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;(null\|\*)&gt;</code> - Returns UpdateCartItemResult or null if error (check console for error)  
**Throws**:

- Error If request fails


| Param | Type | Description |
| --- | --- | --- |
| input | <code>UpdateCart</code> | Follows the GraphQL UpdateCart Mutation Object |
| cartSuccessHandledLocally | <code>boolean</code> | Do not show any success toasts, ask result will be handled locally (useful in the cart, as the change is shown by the update) |
| cartErrorsHandledLocally | <code>boolean</code> | Do not show any error toasts, ask result will be handled locally |

<a name="module_spark.externalClearBasket"></a>

### spark.externalClearBasket() ⇒ <code>Promise.&lt;void&gt;</code>
Call SparkLayer to clear the basket, designed to be used on the thanks page

**Kind**: static method of [<code>spark</code>](#module_spark)  
<a name="module_spark.getProduct"></a>

### spark.getProduct(parentProductId) ⇒ <code>Promise.&lt;Product&gt;</code>
Fetch the graphql product object for a given parent product id

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Throws**:

- If product not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 

<a name="module_spark.getVariant"></a>

### spark.getVariant(parentProductId, variantSku) ⇒ <code>Promise.&lt;ProductVariant&gt;</code>
Fetch the graphql variant object for a given parent product id and variant sku

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Throws**:

- If product/variant not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 
| variantSku | <code>string</code> | 

<a name="module_spark.getPackSizeForVariant"></a>

### spark.getPackSizeForVariant(parentProductId, variantSku) ⇒ <code>Promise.&lt;number&gt;</code>
Fetch the pack size for a variant given parent product id and variant sku

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;number&gt;</code> - Pack Size for Variant  
**Throws**:

- If product/variant not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 
| variantSku | <code>string</code> | 

<a name="module_spark.getRrpPriceForVariant"></a>

### spark.getRrpPriceForVariant(parentProductId, variantSku) ⇒ <code>Promise.&lt;{rrp: (number\|null), currencyCode: string}&gt;</code>
Fetch the RRP price for a variant given parent product id and variant sku

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;{rrp: (number\|null), currencyCode: string}&gt;</code> - RRP price (null if not set for currency) and currency code  
**Throws**:

- If product/variant not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 
| variantSku | <code>string</code> | 

<a name="module_spark.getPricingForVariant"></a>

### spark.getPricingForVariant(parentProductId, variantSku) ⇒ <code>Promise.&lt;{price: number, rrp: number, priceBreaks: Array.&lt;PriceBreaks&gt;, currencyCode: string}&gt;</code>
Fetch the pricing for a variant given parent product id and variant sku

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;{price: number, rrp: number, priceBreaks: Array.&lt;PriceBreaks&gt;, currencyCode: string}&gt;</code> - All price related data for variant  
**Throws**:

- If product/variant not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 
| variantSku | <code>string</code> | 

<a name="module_spark.getPriceForProduct"></a>

### spark.getPriceForProduct(parentProductId) ⇒ <code>Promise.&lt;{numberOfPrices: number, numberOfPricesExcludingBreaks: number, fromPrice: (number\|null), fromPriceExcludingBreaks: (number\|null), rrpPrice: (number\|null), currencyCode: string, hasPriceBreaks: boolean}&gt;</code>
Fetch the pricing for a parent product includes price breaks, lowest price and the number of prices (used to note if from is needed to be shown)

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;{numberOfPrices: number, numberOfPricesExcludingBreaks: number, fromPrice: (number\|null), fromPriceExcludingBreaks: (number\|null), rrpPrice: (number\|null), currencyCode: string, hasPriceBreaks: boolean}&gt;</code> - All price related data for parent product, including price breaks, lowest price and number of prices. Number of prices can be used to note if from is needed to be shown.  
**Throws**:

- If product not found or error occurred fetching product


| Param | Type |
| --- | --- |
| parentProductId | <code>string</code> | 

<a name="module_spark.calculatePricingForVariant"></a>

### spark.calculatePricingForVariant(parentProductId, variantSku, qty, qtyAcrossVariants) ⇒ <code>Promise.&lt;{unitPrice: number, rrp: (number\|null), totalPrice: (number\|null), priceBreakSavingsPercentage: (number\|null), hasPriceBreaks: boolean, currencyCode: (string), priceBreaks: (Array.&lt;PriceBreaks&gt;), basePrice: number}&gt;</code>
Given a product id, sku and quantity, return the price for the product

**Kind**: static method of [<code>spark</code>](#module_spark)  
**Returns**: <code>Promise.&lt;{unitPrice: number, rrp: (number\|null), totalPrice: (number\|null), priceBreakSavingsPercentage: (number\|null), hasPriceBreaks: boolean, currencyCode: (string), priceBreaks: (Array.&lt;PriceBreaks&gt;), basePrice: number}&gt;</code> - Total price (qty * unit price) and unit price  
**Throws**:

- If product/variant not found or error occurred fetching product


| Param | Type | Description |
| --- | --- | --- |
| parentProductId | <code>string</code> |  |
| variantSku | <code>string</code> |  |
| qty | <code>number</code> |  |
| qtyAcrossVariants | <code>number</code> \| <code>null</code> | For tiered pricing, this is calculated by qty across variants (if configured) |

<a name="module_spark.getCart"></a>

### spark.getCart() ⇒ <code>Promise.&lt;object&gt;</code>
Fetch either the local cached cart or fetch the cart from GraphQL

**Kind**: static method of [<code>spark</code>](#module_spark)  
<a name="module_spark..UserData"></a>

### spark~UserData : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type |
| --- | --- |
| id | <code>string</code> | 
| email | <code>string</code> | 
| name | <code>string</code> | 
| companyName | <code>string</code> | 

<a name="module_spark..CartItemInput"></a>

### spark~CartItemInput : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| deltaQuantity | <code>int</code> | The quantity to add or remove from the cart |
| absoluteQuantity | <code>int</code> | The quantity to set the cart item to |
| itemKey | <code>string</code> | Used within the cart to identify the item |
| sku | <code>string</code> | The SKU of the item |

<a name="module_spark..UpdateCart"></a>

### spark~UpdateCart : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| products | <code>Array.&lt;CartItemInput&gt;</code> | An array of products |
| deliveryAddressId | <code>string</code> | The ID of the delivery address |
| customerReference | <code>string</code> | The customer reference |
| clearCart | <code>boolean</code> | Whether to clear the cart or not |
| recreateCartFromTemplateId | <code>string</code> | The ID of the cart template to recreate the cart from |

<a name="module_spark..Price"></a>

### spark~Price : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| taxRate | <code>number</code> | The tax rate (note, tax only supported on Enterprise plans, otherwise will be 0) |
| net | <code>number</code> | The net price |
| gross | <code>number</code> | The gross price (note, only supported on Enterprise plans, due to tax setup) |
| currencyCode | <code>string</code> | The currency code |

<a name="module_spark..PriceBreaks"></a>

### spark~PriceBreaks : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type |
| --- | --- |
| quantity | <code>number</code> | 
| price | <code>Price</code> | 

<a name="module_spark..Product"></a>

### spark~Product : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| id | <code>string</code> | The product ID |
| variants | <code>Array.&lt;ProductVariant&gt;</code> | The product variants |

<a name="module_spark..ProductVariant"></a>

### spark~ProductVariant : <code>Object</code>
**Kind**: inner typedef of [<code>spark</code>](#module_spark)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| id | <code>string</code> | The product ID |
| stockStatus | <code>in\_stock</code> \| <code>backorder</code> \| <code>out\_of\_stock</code> | The stock status |
| cartImageUrl | <code>string</code> | The URL of the product image |
| sku | <code>string</code> | The SKU of the product |
| slug | <code>string</code> | The slug of the product |
| name | <code>string</code> | The name of the product |
| price | <code>Price</code> \| <code>null</code> | The price of the product |
| priceBreaks | <code>Array.&lt;PriceBreaks&gt;</code> | The price breaks of the product |
| rrp | <code>number</code> \| <code>null</code> | The RRP of the product (if available for currency if not null) |
| settings | <code>Array.&lt;{key: string, value: number}&gt;</code> | The settings of the product |
| options | <code>Array.&lt;{group: string, value: string}&gt;</code> | The options of the product |

<a name="module_options"></a>

## options
The options available when using SparkLayer JS, these are set through window.sparkOptions


* [options](#module_options)
    * [~SparkLayerOptions](#module_options..SparkLayerOptions) : <code>Object</code>
    * [~CustomCheckoutElement](#module_options..CustomCheckoutElement) : <code>Object</code>
    * [~CustomCheckoutElementOnChange](#module_options..CustomCheckoutElementOnChange) ⇒ <code>CustomCheckoutElementOnChangeReturn</code>
    * [~CustomCheckoutElementOnChangeReturn](#module_options..CustomCheckoutElementOnChangeReturn) : <code>Object</code>
    * [~TraslationStrings](#module_options..TraslationStrings) : <code>Object</code>

<a name="module_options..SparkLayerOptions"></a>

### options~SparkLayerOptions : <code>Object</code>
**Kind**: inner typedef of [<code>options</code>](#module_options)  
**Access**: public  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| sparkDomain | <code>app.sparklayer.io</code> \| <code>test.app.sparklayer.io</code> | The domain of the SparkLayer API (defaults to app.sparklayer.io) |
| platform | <code>base</code> \| <code>shopify</code> | Sets the default options for the platform |
| siteId | <code>string</code> | The client specific site id |
| rootUrl | <code>string</code> | The root URL used to pre-fix any created URLs - generally used for i18n |
| accountButtonSelectors | <code>string</code> | The selectors for the account button (defaults to `[href="/account"], [data-spark-link=account]`) |
| logoutButtonSelectors | <code>string</code> | The selectors for the logout button (defaults to `[href="/account/logout"], [data-spark-link=logout]`) |
| cartButtonSelectors | <code>string</code> | The selectors for the cart button (defaults to `[href="/cart"], [data-spark-link=cart]`) |
| loginButtonSelectors | <code>string</code> | The selectors for the login button (defaults to `[href="/spark-b2b-login"], [data-spark-link=login]`) |
| display | <code>Object</code> | Options - The display options for the SparkLayer |
| display.customerReferenceHidden | <code>boolean</code> | Whether or not the customer reference is shown (defaults to `false`) |
| display.customerReferenceRequired | <code>boolean</code> | Whether or not the customer reference is required (defaults to `false`) |
| display.customerReferenceMaxLength | <code>boolean</code> | Limit the customer reference field (defaults to `512`) |
| display.darkTheme | <code>boolean</code> | Applies further CSS to ensure our widgets work within dark themes |
| display.savingsUseRrp | <code>boolean</code> | Use RRP instead of a single unit price for savings percentage |
| display.stock | <code>Object</code> |  |
| display.stock.show | <code>boolean</code> | Whether or not to show the stock status (defaults to `false`) |
| display.stock.low | <code>number</code> | The low stock threshold (defaults to `10`) |
| display.stock.last | <code>number</code> | The last stock threshold (defaults to `5`) |
| termsAndConditionsLink | <code>string</code> | Terms and conditions link (defaults to `/terms-and-conditions`) |
| language | <code>string</code> | The language to use for the SparkLayer (defaults to `en`) |
| translations | <code>Object</code> | Override internal translations, keyed by language code |
| showTranslations | <code>boolean</code> | Useful to debug translations, shows the translation key |
| checkoutCustomElements | <code>Array.&lt;CustomCheckoutElement&gt;</code> | A list of custom elements to display in checkout |
| onLoad | <code>function</code> | Called on initial load of Spark JS |
| onReady | <code>function</code> | Called when SparkLayer has the user initialised |
| onCartUpdate | <code>function</code> | Called when the cart has been updated |

<a name="module_options..CustomCheckoutElement"></a>

### options~CustomCheckoutElement : <code>Object</code>
**Kind**: inner typedef of [<code>options</code>](#module_options)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| translations | <code>Object.&lt;string, TraslationStrings&gt;</code> | Traslations for user-facing text |
| name | <code>string</code> | Name for the element. For fields, this name matches the name of the field on the order |
| attributes | <code>Object</code> | HTML attributes to be applied to the element |
| onChange | <code>CustomCheckoutElementOnChange</code> | Function called when the input changes, can be used to validate the input value |

<a name="module_options..CustomCheckoutElementOnChange"></a>

### options~CustomCheckoutElementOnChange ⇒ <code>CustomCheckoutElementOnChangeReturn</code>
**Kind**: inner typedef of [<code>options</code>](#module_options)  

| Param | Type |
| --- | --- |
| value | <code>string</code> | 
| element | <code>HTMLInputElement</code> | 

<a name="module_options..CustomCheckoutElementOnChangeReturn"></a>

### options~CustomCheckoutElementOnChangeReturn : <code>Object</code>
**Kind**: inner typedef of [<code>options</code>](#module_options)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| valid | <code>boolean</code> | Whether the input value is valid |
| messageTranslationKey | <code>string</code> | The validation message to show if the input value is not valid |

<a name="module_options..TraslationStrings"></a>

### options~TraslationStrings : <code>Object</code>
**Kind**: inner typedef of [<code>options</code>](#module_options)  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| title | <code>string</code> | Title of the element. Used as the label for checkboxes |
| detail | <code>string</code> | Additional detail about the element, such as validation requirements |

