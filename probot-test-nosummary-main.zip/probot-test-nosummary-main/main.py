
import os
import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from pydantic import BaseModel
from typing import Optional

from archbee_ai.embedding_retriever import get_openai_embedding_retriever
from archbee_ai.search_pipe import get_openai_search_pipe
from archbee_ai.opensearch_store import os_store
from archbee_ai.embedding_update_cron import embedding_update_job


logging.basicConfig(
    format="%(levelname)s - %(name)s -  %(message)s", level=logging.WARNING)
logging.getLogger("haystack").setLevel(logging.DEBUG)
logging.getLogger("haystack.nodes.retriever.base").setLevel(logging.DEBUG)


app = FastAPI()

API_TOKEN = os.environ.get(
    "API_TOKEN", "134951034985103945cijcqerit203498203948234")


@app.middleware("http")
async def security(request: Request, call_next):

    req_api_token = request.headers.get("X-API-TOKEN")
    # exclude / so that it's able to be used as a healthcheck
    if API_TOKEN == req_api_token or request.url.path == "/":
        response = await call_next(request)
        return response
    else:
        return JSONResponse(status_code=401, content={'reason': 'not allowed'})


@app.get("/")
def root():
    return {"status": "OK"}


class UpdateEmbeddingsRequest(BaseModel):
    docIds: Optional[list[str]]
    docSpaceId: Optional[str]
    teamId: Optional[str]
    openAiKey: Optional[str]


@app.post("/update-embeddings")
def update_doc_embeddings(updateEmbeddingsRequest: UpdateEmbeddingsRequest):

    docIds = updateEmbeddingsRequest.docIds
    docSpaceId = updateEmbeddingsRequest.docSpaceId
    teamId = updateEmbeddingsRequest.teamId
    openAiKey = updateEmbeddingsRequest.openAiKey

    if not openAiKey:
        return {"status": "not ok, no open ai key supplied"}

    filters = {}
    if docIds:
        filters["_id"] = docIds
    if docSpaceId:
        filters["docSpaceId"] = docSpaceId
    if teamId:
        filters["teamId"] = teamId

    embedding_retriever = get_openai_embedding_retriever(
        os_store, openai_key=openAiKey)

    batch_size = 10 if not docIds else len(docIds)

    os_store.update_embeddings(
        retriever=embedding_retriever, batch_size=batch_size, filters=filters)

    return {"status": "ok"}


class SearchRequestModel(BaseModel):
    query: str
    teamId: Optional[str]
    docSpaceId: Optional[str]
    openAiKey: Optional[str]


@app.post("/search")
def search_doc(_q: SearchRequestModel):

    query = _q.query
    teamId = _q.teamId
    docSpaceId = _q.docSpaceId
    openAiKey = _q.openAiKey

    if teamId is None and docSpaceId is None:
        return {"status": "not-ok", "messages": ["team_id or docspace_id needs to be provided"]}

    if not openAiKey:
        return {"status": "not-ok", "messages": ["open ai key needs to be provided"]}

    filters = {}
    if teamId:
        filters['teamId'] = teamId
    if docSpaceId:
        filters['docSpaceId'] = docSpaceId

    search_pipe = get_openai_search_pipe(os_store, openAiKey)

    prediction = search_pipe.run(
        query=query,
        params={
            "Retriever": {"top_k": 10},
            "filters": filters
        }
    )

    return {"status": "ok", "prediction": prediction}
